//Guess a Number Game Final_Project
#include<iostream>
#include <stdlib.h>
#include <time.h>
using namespace std;
bool HighOrLow(int a, int b) //User-defined function to determine whether the guess is too high or too low
{
	if (a < b) //if the guess is less than the random number
		return true; //Too low
	else if (a > b) // if the guess is greater than the random number
		return false; //Too high
}
int main()
{
	int num, guess, replay, counter; // declare variables for the random number, the users input, and a counter for the number of attempts
	srand(time(0)); //seed random number generator
	do
	{
		counter = 0;
		num = rand() % 100 + 1; // make number a random number from 1 to 100 using the formula for random number range
		cout << "Guess The Number Game\n\n"; // display the title of the game
		do // using do while loop
		{
			cout << "Enter a guess between 1 and 100 : "; // prompt user to enter a guess between 1 and 100
			cin >> guess; //take users input
			counter++; // add 1 to the counter for every guess
			if (guess < 1 || guess > 100) //if guess is out of the range
				cout << "Invalid input, try another number\n\n";//invalide input
			else if(HighOrLow(guess, num) == 1) // if the user define function returns true
				cout << "Too Low\n\n"; //display that the number is too low
			else if (HighOrLow(guess, num) == 0) //if the function returns false
				cout << "Too High\n\n"; // display that the number is too high
			else if (guess == num) //if guess is equal to the number
				cout << "\nCorrect, you got it in " << counter << " guesses" << endl<<endl; // display that the answer is correct and display the amount of attempts

		} while (guess != num); //stop running code when guess is equal to numnber
		cout << "Would you like to play again ?(-1 to play again)\n"; //prompt user to play again by entering -1
		cin >> replay; //take users input
	} while (replay == -1); // if user enters -1 then the game starts over
	return 0;
}