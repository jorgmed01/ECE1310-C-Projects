#include <iostream>
#include <ctime>
#include <cmath>
#include <stdlib.h>
using namespace std;
int GetRandom(int a, int b)
{
	int swapped, random;
	if (a > b) {
		swapped = a;
		a = b;
		b = swapped;
	}
	return random = (rand() % (b - a + 1)) + a;
}
int GetCount(int a[], int m)
{
	int count=0;
	for (int i = 0; i < 30; i++)
	{
		if (a[i] < m) {
			count++;
		}
	}
	return count;
}
void HighLow(int arr[], int& high, int& low,int& MinDay, int& MaxDay) // pass by refernece using the adress of the variables
{
	for (int i = 0; i < 30; i++) //for loop to test values of temp and to record the day of each max and min
		if (arr[i] < low) { // compare value for array on each day to value low
			low=arr[i]; // if the array is smaller than the value for low at any time, make it the new low value
			MinDay=i +1 ; // record the day for low
		}
		else if (arr[i] > high) { // if the value for the array is greater than the highest value run this code
			high=arr[i]; // if the value for the array on a given day is greater than high, then make it the new high value
			MaxDay=i +1; // record the day for high
		}
}
int main()
{
	int a, b;
	int high, low, MinDay, MaxDay;
	int arr[30] = {};
	srand(time(0));
	for (int i = 0; i < 30; i++) {
		arr[i] = GetRandom(21, 45);
	}
    high = arr[0];
    low = arr[0];
    //Display
    cout << "Date:\t";
    for (int j = 1; j < 11; j++) {
        if (j < 10) {
            cout << "Nov.0" << j << "\t";
        }
        else {
            cout << "Nov." << j << "\t";
        }
    }
    cout << "\nTemp:\t";
    for (int j = 0; j < 10; j++) {
        cout << arr[j] << "\t";
    }
    cout << "\nDate:\t";
    for (int j = 11; j < 21; j++) {
        if (j < 10) {
            cout << "Nov.0" << j << "\t";
        }
        else {
            cout << "Nov." << j << "\t";
        }
    }
    cout << "\nTemp:\t";
    for (int j = 10; j < 20; j++) {
        cout << arr[j] << "\t";
    }

    cout << "\nDate:\t";
    for (int j = 21; j < 31; j++) {
        if (j < 10) {
            cout << "Nov.0" << j << "\t";
        }
        else {
            cout << "Nov." << j << "\t";
        }
    }
    cout << "\nTemp:\t";
    for (int j = 20; j < 30; j++) {
        cout << arr[j] << "\t";
    }
	HighLow(arr, high, low, MinDay, MaxDay);
	cout << endl<< "The warmest day is Nov " << MaxDay << " with a temp of " << high << endl;
	cout << "The coldest day is Nov " << MinDay << " with a temp of " << low << endl;
	cout << "There are " << GetCount(arr, 32) << " days in the month that have a temp lower than 32 degrees" << endl;
}