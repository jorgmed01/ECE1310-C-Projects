#include <iostream>
using namespace std;
int main()
{
	int x, y, z;
	cout << "please enter three whole numbers\n";
	cin >> x;
	cin >> y;
	cin >> z;
	if (x < 0 || y < 0 || z < 0)
	{
		cout << "Invalid input";
		return 0;
	}
	else if (x > y) {
		if (x > z) {
			cout << "x is hypotenuse\n";
			if (x * x == y * y + z * z) {
				cout << "Right Triangle";
				return 0;
			}
			else
				cout << "Not a right triangle";
			return 0;
		}
	}
	else if (y > z) {
		cout << "y is the hypotenuse\n";
		if (y * y == x * x + z * z) {
			cout << "Right triangle";
			return 0;
		}
		else
			cout << "Not a Right Triangle";
		return 0;
	}
	else
		cout << "z is hypotenuse\n";
	if (z * z == x * x + y * y) {
		cout << "Right Triangle";
		return 0;
	}
	else
		cout<< "Not a Right Triangle";
	return 0;
}