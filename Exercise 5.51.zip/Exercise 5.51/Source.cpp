#include <iostream>
#include <cmath>
using namespace std;
int tripleByValue(int x)// function that passes a copy of count by value, triples the copy and returns the new value
{
	return 3 * x; //returns triple the value of the copy
}
void tripleByReference(int& x) // function that passes count by reference and triples its value without returning a new value
{
	x = 3 * x; // x is multiplied by 3 to triple its value
}
int main() //main function
{
	int count = 4; //variable count is declared and initialized to 4
	cout << count << endl; //the origianl value of count is displayed
	cout << tripleByValue(count) << endl; // tripleByValue function is displayued
	tripleByReference(count); // tripleByReference changes the value for count
	cout << count; //count is displayed after being altered through tripleByReference
}