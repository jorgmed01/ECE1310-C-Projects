#include <iostream>
using namespace std;
int main()
{
	//Declare variable to keep track of the number of multiples of 7
	int counter;
	//Declare a variable to keep track of the sum of the multiples of 7
	int sum;
	//Initialize variables to starting point 0
	counter = 0;
	sum = 0;
	//introduce the list
	cout << "The multiples of 7 (from 1-600) are : ";
	//Set up for loop with x starting at 1 and moving up to 600 with increments of +1 every time it loops
	for (int x = 1; x <= 600; x++) {
	//To find multiple of 7, have the remainder of x divided by 7 equal to 0 using modulus
		if (x % 7 == 0) {
			//if x is the last multiple of 7 before reaching 600 then end the list
			if (x == 595) {
				//print 595 if the condition is true
				cout << x << ".";
				//add 1 to the counter if condition is true
				counter++;
				//add x to the sum if condition is true
				sum += x;
				//this is the end of the list so we then break the loop
				break;
			}
			//print x value whenever x % 7 is equal to 0 followed by a comma
			cout << x << ", ";
			//add 1 to the counter everytime the condition is true
			counter++;
			//add the value of x to the sum everytime the condition is true
			sum += x;
		}
	}//end loop
	//print the number of multiples of 7 there are between 1 and 600 using the counter variable
	cout << "\nThere are " << counter << " multiples of 7 between 1 and 600\n";
	//print the sum of all multiples of 7 between 1 and 600 using the sum variable
	cout << "The sum of all multiples of 7 between 1 and 600 is : " << sum;
}//end main